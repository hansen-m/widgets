// Global Variables
var tickInterval;
var time;

// Function: load()
// Called by HTML body element's onload event when the widget is ready to start
//
function load(){
    setupParts();
	clearInterval(tickInterval);
	tickInterval = null;
	time = 0;
    
    //Set Preferences
    $("maxdur-popup").value = widget.preferenceForKey("maxDur");
    $("script-popup").object.setSelectedIndex(widget.preferenceForKey("actScpt"));
}

//
// Function: sync()
// Called when the widget has been synchronized with .Mac
//
function sync(){
    //Set Preferences
    $("maxdur-popup").value = widget.preferenceForKey("maxDur");
    $("script-popup").object.setSelectedIndex(widget.preferenceForKey("actScpt"));
}

//
// Function: remove()
// Called when the widget has been removed from the Dashboard
//
function remove(){
	clearInterval(tickInterval);
}

//
// Function: hide()
// Called when the widget has been hidden
//
function hide(){

}

//
// Function: show()
// Called when the widget has been shown
//
function show(){
    // Restart any timers that were stopped on hide
}

//
// Function: showBack(event)
// Called when the info button is clicked to show the back of the widget
//
// event: onClick event from the info button
//
function showBack(event){
    var front = document.getElementById("front");
    var back = document.getElementById("back");

    if (window.widget) {
        widget.prepareForTransition("ToBack");
    }

    front.style.display = "none";
    back.style.display = "block";

    if (window.widget) {
        setTimeout('widget.performTransition();', 0);
    }
}

//
// Function: showFront(event)
// Called when the done button is clicked from the back of the widget
//
// event: onClick event from the done button
//
function showFront(event){
    
    var front = document.getElementById("front");
    var back = document.getElementById("back");

    if (window.widget) {
        widget.prepareForTransition("ToFront");
    }

    front.style.display="block";
    back.style.display="none";

    if (window.widget) {
        setTimeout('widget.performTransition();', 0);
    }
}

if (window.widget) {
    widget.onremove = remove;
    widget.onhide = hide;
    widget.onshow = show;
    widget.onsync = sync;
}

function setTimer(dec){
	time = (dec * (parseInt($("maxdur-popup").value) * 3600)).toFixed(0);
	var hours = Math.floor(time / 3600);
	var minutes = Math.floor((time % 3600) / 60);
	var seconds = Math.floor((time % 3600) % 60);
	$("txt-seconds").innerHTML = doubleDigits(seconds);
	$("txt-minutes").innerHTML = doubleDigits(minutes);
	$("txt-hours").innerHTML = doubleDigits(hours);
}

function startTimer(){
	if (tickInterval != null){
		clearInterval(tickInterval);
		tickInterval = null;
		$("button-start").style.visibility = "visible";
		$("button-stop").style.visibility = "hidden";
	}else{
		tickInterval = setInterval("tick()",1000);
		$("button-stop").style.visibility = "visible";
		$("button-start").style.visibility = "hidden";
	}
}

function tick(){
	if (time > 0){
		time = (time - 1);
		var hours = Math.floor(time / 3600);
		var minutes = Math.floor((time % 3600) / 60);
		var seconds = Math.floor((time % 3600) % 60);
	
		$("txt-seconds").innerHTML = doubleDigits(seconds);
		$("txt-minutes").innerHTML = doubleDigits(minutes);
		$("txt-hours").innerHTML = doubleDigits(hours);

	}else{
		clearInterval(tickInterval);
		tickInterval = null;
		$("button-start").style.visibility = "visible";
		$("button-stop").style.visibility = "hidden";
        
        $("timeslider").object.setValue(0);
        $("timeslider").object.refresh();
		
        timeReached();
	}
}

function timeReached(){
	if (getScript() == "itplay"){
		widget.system("/usr/bin/osascript -e 'tell application \"iTunes\" to play'" , timeAlert('iTunes Playing'));
	}else if (getScript() == "macsleep"){
		widget.system("/usr/bin/osascript -e 'tell application \"System Events\" to sleep'", timeAlert('Sleeping Mac'));
    }else if (getScript() == "qtclose"){
        widget.system("/usr/bin/osascript -e 'tell application \"QuickTime Player\" to quit'" , timeAlert('QuickTime Paused'));
    }else if (getScript() == "dvdclose"){
        widget.system("/usr/bin/osascript -e 'tell application \"DVD Player\" to quit'" , timeAlert('DVD Player Quit'));
    }else if (getScript() == "itpause"){
		widget.system("/usr/bin/osascript -e 'tell application \"iTunes\" to pause'" , timeAlert('iTunes Paused'));
	}
}

function doubleDigits(number)
{
    var digits = number.toString(10);
    if (digits.length == 1) {
        digits = "0" + digits;
    }
    return digits;
}

function setKeyTime(e){
    var ekeyCode = e.keyCode;
    var value = String.fromCharCode(ekeyCode);
}

function getScript(){
	return $("script-popup").object.getValue();
}

function setPrefs(){
    widget.setPreferenceForKey($("maxdur-popup").value, "maxDur");
    widget.setPreferenceForKey($("script-popup").object.getSelectedIndex(), "actScpt");
}

function $(id) {
	return document.getElementById(id);
}

function timeAlert(message){
    //display time  alert
}

function openURL(){
	widget.openURL('http://web.me.com/hansen.m')
}
